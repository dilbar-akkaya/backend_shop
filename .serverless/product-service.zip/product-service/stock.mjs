import { productsDB } from "./products.mjs";

export const stockDB = [
    {
        product_id: productsDB[0].id,
        count: 4,
    },
    {
        product_id: productsDB[1].id,
        count: 5,
    },
    {
        product_id: productsDB[2].id,
        count: 2,
    }
]