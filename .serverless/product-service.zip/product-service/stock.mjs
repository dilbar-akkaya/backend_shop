import { productsDB } from "./products.mjs";

export const stockDB = [
    {
        product_id: productsDB[0].id,
        count: 10,
    },
    {
        product_id: productsDB[1].id,
        count: 10,
    },
    {
        product_id: productsDB[2].id,
        count: 10,
    }
]